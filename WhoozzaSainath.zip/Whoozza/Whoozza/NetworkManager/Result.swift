//
//  Result.swift
//  Whoozza
//
//  Created by sainath on 08/03/22.
//

import Foundation
import Foundation
class TrukkerResult<T>: Codable where T: Codable {
    var success: Bool
    var data: T?
    private enum CodingKeys: String, CodingKey {
        case success
        case data
    }
    required init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        success = try values.decode(Bool.self, forKey: .success)
        data = try values.decodeIfPresent(T.self, forKey: .data)
   }
}
