//
//  TLWebService.swift
//  TrukkerLoad
//
//  Created by Nandeesh on 18/10/21.
//

import Foundation

struct WebService {
    struct ProductionServer {
        static let baseURL = "prod.trukker.com/"
    }
    struct StagingServer {
        static let baseURL = "http://dev.propennyauction.com/"
    }
    struct APIParameterKey {
        static let mobileNumber = "mobileNumber"
        static let OTP = "OTP"
        static let PIN = "PIN"
    }
}

enum HTTPHeaderField: String {
    case authentication = "Authorization"
    case contentType = "Content-Type"
    case acceptType = "Accept"
    case acceptEncoding = "Accept-Encoding"
}

enum ContentType: String {
    case json = "application/json"
}

enum WebServiceAPI: String {
    // Onboarding
    case homeVideosUrl
    case videoLiked

    // MARK: API Path
    var path: String {
        switch self {
            // MARK: - Onboarding
        case .homeVideosUrl:
            
        return "api_video/home.php"
        case .videoLiked:
            return "api_video/like_video.php"
       
        }
    }
}
