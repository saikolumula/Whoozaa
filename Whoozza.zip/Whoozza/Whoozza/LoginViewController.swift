//
//  LoginViewController.swift
//  Whoozza
//
//  Created by sainath on 10/03/22.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var userNameTextfield: UITextField!
    @IBOutlet weak var emailTextfield: UITextField!
    
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var continueWithGoogleView: UIView!
    @IBOutlet weak var continueWithFacebookView: UIView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        loginButton.layer.cornerRadius = 20
        continueWithGoogleView.layer.cornerRadius = 5
        continueWithFacebookView.layer.cornerRadius = 5

    }
    
    @IBAction func continueWithGoogleAction(_ sender: Any) {
    }
    
    @IBAction func continueWithFacebookAction(_ sender: Any) {
    }
    
    @IBAction func createAction(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(identifier: "MenuScreenViewController") as! MenuScreenViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func loginAction(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(identifier: "MenuScreenViewController") as! MenuScreenViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }

    
}
