//
//  HeaderManager.swift
//  TrukkerLoad
//
//  Created by Sunith on 11/11/21.
//

import Foundation

import UIKit

@objcMembers
class HeaderManager: NSObject {
    static let shared = HeaderManager()
    private var headers = [String: String]()
    private override init() {
        super.init()
        setDeafultHeaders()
    }
    func setDeafultHeaders() {
//        let cache = Cache.shared
//        let environment = cache.currentEnvironment

        if headers.count > 0 {
            headers = [String: String]()
        }
        headers["Accept"] = "application/json"
        headers["Accept-Language"] = "en"
        headers["device-type"] = UIDevice.current.systemName
        headers["os"] = "iOS_\(UIDevice.current.systemVersion)"
//        headers["client-id"] = cache.clientId
//        headers["client-auth-method"] = environment.clientAuthMethod
//        headers["secret-key"] = environment.secretKey
//        headers["api-version"] = cache.apiVersion
//        headers["device-id"] = cache.deviceId
//        headers["appVersion"] = cache.appVersion
//        headers["appBuild"] = cache.appBuild
//        headers["install-id"] = cache.installId
        headers["Content-Type"] = "application/json"
    }
    func getHeaders() -> [String: String] {
        headers
    }
}
