//
//  HomeModel.swift
//  Whoozza
//
//  Created by sainath on 09/03/22.
//

import Foundation
// MARK: - HomePAgeDATA
struct HomePageViewModel: Codable {
    let success: Bool?
    let data: [HomeModel]?
    
    enum CodingKeys: String, CodingKey {
        case success
        case data
    }
}

// MARK: - Datum
struct HomeModel: Codable {
    let id, userID, title: String
    let video: String
    let likeCnt, status, created: String
    let showLikeBtn: Int
    
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case userID = "user_id"
        case title = "title"
        case  video = "video"
        case likeCnt = "like_cnt"
        case status = "status"
        case created = "created"
        case showLikeBtn = "show_like_btn"
    }
}
