//
//  MenuScreenViewController.swift
//  Whoozza
//
//  Created by sainath on 10/03/22.
//

import UIKit

class MenuScreenViewController: UIViewController {

    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var inviteFrndsView: UIView!
    
    @IBOutlet weak var myAccountView: UIView!
    @IBOutlet weak var notificationView: UIView!
    @IBOutlet weak var helpCenterView: UIView!
    @IBOutlet weak var contactView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        inviteFrndsView.layer.cornerRadius = 20
        myAccountView.layer.cornerRadius = 5
        notificationView.layer.cornerRadius = 5
        helpCenterView.layer.cornerRadius = 5
        
        closeButton.layer.borderWidth = 1
        closeButton.layer.masksToBounds = false
        closeButton.layer.borderColor = UIColor.clear.cgColor
        closeButton.layer.cornerRadius = closeButton.frame.height/2
        closeButton.clipsToBounds = true
        
        cameraButton.layer.borderWidth = 1
        cameraButton.layer.masksToBounds = false
        cameraButton.layer.borderColor = UIColor.clear.cgColor
        cameraButton.layer.cornerRadius = closeButton.frame.height/2
        cameraButton.clipsToBounds = true
        
        contactView.layer.borderWidth = 1
        contactView.layer.masksToBounds = false
        contactView.layer.borderColor = UIColor.clear.cgColor
        contactView.layer.cornerRadius = contactView.frame.height/2
        contactView.clipsToBounds = true


        // Do any additional setup after loading the view.
    }
    
    @IBAction func myAccountAction(_ sender: Any) {
    }
    @IBAction func notificationAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "NonLoginUserHomeViewController") as! NonLoginUserHomeViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func helpCenterAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "NonLoginUserHomeViewController") as! MenuScreenViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
