//
//  HomeCell.swift
//  Whoozza
//
//  Created by sainath on 08/03/22.
//

import UIKit
import AVFoundation

class HomeCell: UICollectionViewCell {
    
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var playerContainerView: UIView!
    @IBOutlet weak var addIMageButton: UIButton!
    @IBOutlet weak var userProfileButton: UIButton!
    
    @IBOutlet weak var userLIkeLabel: UILabel!
    @IBOutlet weak var userCommentedLabel: UILabel!
    
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userFollowLabel: UILabel!
    @IBOutlet weak var userMusicLabel: UILabel!
    
    
    var playerView: PlayerVideoView = {
        var player = PlayerVideoView()
        player.backgroundColor = .cyan
        return player
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        userImageView.layer.borderWidth = 1
        userImageView.layer.masksToBounds = false
        userImageView.layer.borderColor = UIColor.white.cgColor
        userImageView.layer.cornerRadius = userImageView.frame.height/2
        userImageView.clipsToBounds = true
        userImageView.layer.borderWidth = 5
        
        addIMageButton.layer.borderWidth = 1
        addIMageButton.layer.masksToBounds = false
        addIMageButton.layer.borderColor = UIColor.clear.cgColor
        addIMageButton.layer.cornerRadius = addIMageButton.frame.height/2
        addIMageButton.clipsToBounds = true
        
        
        userProfileButton.layer.borderWidth = 1
        userProfileButton.layer.masksToBounds = false
        userProfileButton.layer.borderColor = UIColor.white.cgColor
        userProfileButton.layer.cornerRadius = userProfileButton.frame.height/2
        userProfileButton.layer.borderWidth = 5
        
        playerContainerView.addSubview(playerView)
        // we are taking care of the constraints
        playerView.translatesAutoresizingMaskIntoConstraints = false
        // pin the image to the whole collectionview - it is the same size as the container
        playerView.topAnchor.constraint(equalTo: topAnchor).isActive = true
        playerView.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        playerView.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        playerView.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
    }

    // The AVPlayer
    var videoPlayer: AVPlayer? = nil

//    func playVideo() {
//        
//        guard let path = Bundle.main.path(forResource: "AppInventorL1Setupemulator", ofType:"mp4") else {
//            debugPrint("video.m4v not found")
//            return
//        }
//        // set the video player with the path
//        videoPlayer = AVPlayer(url: URL(fileURLWithPath: path))
//        // play the video now!
//        videoPlayer?.playImmediately(atRate: 1)
//        // setup the AVPlayer as the player
//        playerView.player = videoPlayer
//    }

    func stopVideo() {
        playerView.player?.pause()
    }
}
