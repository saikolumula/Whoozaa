//
//  ProfilePageViewController.swift
//  Whoozza
//
//  Created by sainath on 10/03/22.
//

import UIKit

class ProfilePageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
  
    @IBAction func LoginAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "MenuScreenViewController") as! MenuScreenViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func SignUpAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "MenuScreenViewController") as! MenuScreenViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
